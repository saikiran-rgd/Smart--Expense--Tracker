package in.codingstreams.etexpenseservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EtExpenseServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EtExpenseServiceApplication.class, args);
	}

}
