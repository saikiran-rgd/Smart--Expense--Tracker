package in.codingstreams.etuserauthservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EtUserAuthServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EtUserAuthServiceApplication.class, args);
	}

}
