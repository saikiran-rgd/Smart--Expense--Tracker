package in.codingstreams.etbffservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EtBffServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EtBffServiceApplication.class, args);
	}

}
