package in.codingstreams.etexpensereportsservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EtExpenseReportsServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EtExpenseReportsServiceApplication.class, args);
	}

}
